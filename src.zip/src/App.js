import './App.css';

import Section1 from "./components/Section1/Section1";

function App() {
    return (
        <div className="App">
            <Section1/>
        </div>
    );
}

export default App;
