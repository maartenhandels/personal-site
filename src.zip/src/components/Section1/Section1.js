import React, {useRef, useEffect} from "react";

import classes from "./Section1.module.css";

import NavBar from "../NavBar/NavBar";
import Section from "../Section/Section";

const Section1 = () => {
    const navbarRef = useRef(null);
    const section1Ref = useRef(null);

    useEffect(() => {
        if (navbarRef.current && section1Ref.current) {
            const navbarHeight = navbarRef.current.offsetHeight;
            section1Ref.current.style.height = `calc(100vh - ${navbarHeight}px)`;
        }
    }, []);

    return (
        <>
            <NavBar ref={navbarRef}/>
            <Section ref={section1Ref} className={classes.Section1}>
                <div>Hello World</div>
            </Section>
            <Section className={classes.Section1}>
                <div>Hello World</div>
            </Section>
        </>
    )
}

export default Section1;